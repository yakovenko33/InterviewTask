<?php

namespace src\Controller;

class ExampleController
{
    /*
     * route = example/index
    */
    public function indexAction()
    {
        print_r('Hello World, Pidar!');
        exit;
    }
}