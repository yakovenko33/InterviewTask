<?php
 return array(
            'host' => '127.0.0.1',
            'db'   => 'interview',
            'user' => 'root',
            'pass' => '',
            'charset' => 'utf8'
        );
